// Copyright Ian Flint 2019, distributed under the MIT License.

#define CATCH_CONFIG_MAIN

#include "../external/Catch2/single_include/catch2/catch.hpp"
