#include "print_buffer_to_stdout.hpp"

#include <rngpp/sfc.hpp>

#include <cstdint>

int main() {
  using Generator = rngpp::sfc64;
  Generator generator{42};

  rngpp::tools::print_buffer_to_stdout<std::uint64_t>(generator);
}
